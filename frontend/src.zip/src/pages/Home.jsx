import React from "react";

const Home = () => {
  return <h1 className="text-2xl text-center mt-10">Welcome to the Home Page</h1>;
};

export default Home;